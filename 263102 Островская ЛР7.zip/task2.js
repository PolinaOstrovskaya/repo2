function changeTheme(isChecked) {
    if (isChecked) {
      document.body.setAttribute('dark', '');
      document.getElementById("Image1").src="7767878bbe015539911cff3c077d63bf.jpg";
    } else {
      document.body.removeAttribute('dark');
      document.getElementById("Image1").src="de6aeffee2ad490f2c06be0730812785.jpg"
    }
  }